//
//  ViewController.swift
//  ConVo
//
//  Created by Conley McKown on 11/1/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import UIKit
import Speech

class ViewController: UIViewController {

    let dataProvider = DataProvider.shared
    let audioManager = AudioManager.shared
    let notificationKeyword = NSNotification.Name("new keyword added to values")
    let notificationArticle = NSNotification.Name("new article added to values")

    fileprivate var infoLabel = YourLabel()
    fileprivate var colorView = UIButton()
    fileprivate var tableView = UITableView()
    fileprivate var tableView2 = UITableView()

    fileprivate var keywords = [KeyWordResult]()
    fileprivate var articles = [KeyWordResult]()

    fileprivate var selected = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        audioManager.setLabel(label: infoLabel)
    }

    @objc fileprivate func changeButtonColor() {
        selected.toggle()
        switch selected {
        case true:
            audioManager.isOn = true
            colorView.backgroundColor = .blue
        case false:
            audioManager.isOn = false
            colorView.backgroundColor = .gray
        }
    }
    
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableView {
            return keywords.count
        } else {
            return articles.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        if tableView == self.tableView {
            cell.textLabel?.text = keywords[indexPath.row].keyword
        } else {
            cell.textLabel?.text = articles[indexPath.row].keyword
        }
        return cell
    }
    
    
}



extension ViewController {
    
    fileprivate func setupViews() {
        
        
        colorView.backgroundColor = .gray
        colorView.translatesAutoresizingMaskIntoConstraints = false
        colorView.addTarget(self, action: #selector(changeButtonColor), for: .touchUpInside)
        self.view.addSubview(colorView)
        NSLayoutConstraint.activate([
            colorView.widthAnchor.constraint(equalTo: self.view.widthAnchor),
            colorView.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.1),
            colorView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor),
            colorView.centerXAnchor.constraint(equalTo: self.view.centerXAnchor)
        ])

        
        infoLabel.text = ""
        infoLabel.numberOfLines = 0
        infoLabel.textAlignment = .center
        infoLabel.translatesAutoresizingMaskIntoConstraints = false

        self.view.addSubview(infoLabel)

        NSLayoutConstraint.activate([
            infoLabel.widthAnchor.constraint(equalTo: self.view.widthAnchor),
            infoLabel.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.2),
            infoLabel.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            infoLabel.bottomAnchor.constraint(equalTo: colorView.topAnchor)
        ])
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.translatesAutoresizingMaskIntoConstraints = false

        self.view.addSubview(tableView)
        NSLayoutConstraint.activate([
            tableView.leftAnchor.constraint(equalTo: self.view.leftAnchor),
            tableView.rightAnchor.constraint(equalTo: self.view.centerXAnchor),
            tableView.bottomAnchor.constraint(equalTo: infoLabel.topAnchor),
            tableView.topAnchor.constraint(equalTo: self.view.topAnchor)
        ])
        
        tableView2.delegate = self
        tableView2.dataSource = self
        tableView2.translatesAutoresizingMaskIntoConstraints = false

        self.view.addSubview(tableView2)
        NSLayoutConstraint.activate([
            tableView2.leftAnchor.constraint(equalTo: self.view.centerXAnchor),
            tableView2.rightAnchor.constraint(equalTo: self.view.rightAnchor),
            tableView2.bottomAnchor.constraint(equalTo: infoLabel.topAnchor),
            tableView2.topAnchor.constraint(equalTo: self.view.topAnchor)
        ])

        
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(onDidReceiveData),
            name: notificationKeyword,
            object: nil
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(onDidReceiveArticle),
            name: notificationArticle,
            object: nil
        )


    }
    
    @objc func onDidReceiveArticle() {
        print("|\n|\n|\n|\n|\n")
        let curCount = articles.count
        articles = dataProvider.articles
        let newCount = articles.count
        
        for article in articles {
            print(article.keyword)
        }
        
        var indexPaths = [IndexPath]()
        for i in 0..<(newCount - curCount) {
            indexPaths.append(IndexPath(row: i, section: 0))
        }
        
        tableView2.beginUpdates()
        tableView2.insertRows(at: indexPaths, with: .automatic)
        tableView2.endUpdates()

    }

    
    @objc func onDidReceiveData() {
        let curCount = keywords.count
        keywords = dataProvider.values
        let newCount = keywords.count
        
        var indexPaths = [IndexPath]()
        for i in 0..<(newCount - curCount) {
            indexPaths.append(IndexPath(row: i, section: 0))
        }
        
        tableView.beginUpdates()
        tableView.insertRows(at: indexPaths, with: .automatic)
        tableView.endUpdates()
        
    }
    
}

class YourLabel: UILabel {

    override var text: String? {
        didSet {
            if text?.count ?? 0 > 100 {
                text = String((text?.dropFirst(text!.count - 100))!)
            } else {

            }
        }
    }
    
}
