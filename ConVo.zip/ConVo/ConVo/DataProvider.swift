//
//  DataProvider.swift
//  ConVo
//
//  Created by Conley McKown on 11/1/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit

class KeyWordResult {
    var keyword = ""
    var id = ""
    var articles: [String]?
//        [
//        "The morning after Donald Trump was elected President of the United States, Barack Obama summoned staff members to the Oval Office. Some were fairly junior and had never been in the room before. ",
//        "“This is not the apocalypse,” Obama said.",
//        "Obama’s mockery of Trump began as early as the 2011 White House Correspondents’ Dinner",
//        "For tens of millions of Americans, Trump was unthinkable as President. It came to be conceded that he had “tuned into something”: the frequencies of white rural life, the disaffection of people who felt overwhelmed by the forces of globalization, who felt unheard and condescended to by the coastal establishment",
//        "A man of inherited fortune and a stint at the Wharton School was an unlikely champion of the rural South and the Rust Belt"
//        ]
    var type = ""
    var cellHeight: CGFloat = 0.0
    var isLoaded = false
}

class DataProvider {
    
    static let shared = DataProvider.init()
    
    public var values = [KeyWordResult]()
    public var articles = [KeyWordResult]()
    let notificationKeyword = NSNotification.Name("new keyword added to values")
    let notificationArticle = NSNotification.Name("new article added to values")

    fileprivate var baseURL = "https://hsn.kwa.mybluehost.me/scripts/request.php?"

    private init() {
        
    }
    
    public func getArticle(result: KeyWordResult) {
        let urlString =
            baseURL +
                "keyword=" + result.keyword.replacingOccurrences(of: " ", with: "%20") +
                "&id=" + result.id.replacingOccurrences(of: " ", with: "%20") +
                "&type=" + result.type.replacingOccurrences(of: " ", with: "%20")

        if let url = URL(string: urlString) {
            makeRequest(url: url)
        }
    }

    
    public func getKeywords(sentence: String) {
        let urlString = baseURL + "sentence=" + sentence.replacingOccurrences(of: " ", with: "%20").replacingOccurrences(of: "'", with: "%27")
        if let url = URL(string: urlString) {
            makeRequest(url: url)
        }
    }
    
    private func makeRequest(url: URL) {
        //create the session object
        let session = URLSession.shared
        
        //now create the URLRequest object using the url object
        var request = URLRequest(url: url)
        request.httpMethod = "GET" //set http method as POST

        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")

        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in

            guard let data = data else {
                print("data = data")
                return
            }

            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .fragmentsAllowed) as? [String: Any] {
                    for str in (json["value"] as? [[String: Any]] ?? [[String: Any]]()) {
                        let newKeyWordResult = KeyWordResult()
                        newKeyWordResult.keyword = str["string"] as! String
                        newKeyWordResult.id = str["id"] as! String
                        newKeyWordResult.type = str["type"] as! String
                        newKeyWordResult.cellHeight = CGFloat(Int.random(in: 50...200))
                        
                        self.values.insert(newKeyWordResult, at: 0)

                        self.getArticle(result: newKeyWordResult)
                        
                        DispatchQueue.main.async {
                            NotificationCenter.default.post(name: self.notificationKeyword, object: nil)
                        }
                    }
                    // handle json...
                    
                    if var headlines = json["headlines"] as? [String] {
                        let id = json["id"] as? String
                        for result in self.values {
                            if result.id == id ?? "" {
                                
                                for (i, headline) in headlines.enumerated() {
                                    if headline.lowercased().contains("view all") {
                                        headlines.remove(at: i)
                                    }
                                }
                                
                                result.articles = headlines
                                DispatchQueue.main.async {
                                    NotificationCenter.default.post(name: self.notificationArticle, object: nil)
                                }
                            }
                        }
                    }
                }
            } catch let error {
                print("error")
                print(error.localizedDescription)
            }
        })
        task.resume()

    }
    

    
    
}
