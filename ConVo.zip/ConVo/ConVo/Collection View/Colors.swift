//
//  Colors.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit

class Colors {
    static var green  = UIColor(hex: 0x27c5ab)
    static var blue   = UIColor(hex: 0x37b2cb)
    static var purple = UIColor(hex: 0x605f9d)
    static var red    = UIColor(hex: 0xe9686d)
    static var orange = UIColor(hex: 0xf67b5e)
    
    static func random() -> UIColor {
        let num = Int.random(in: 0...4)
        
        switch num {
        case 0:
            return green
        case 1:
            return blue
        case 2:
            return purple
        case 3:
            return red
        default:
            return orange

        }
        
    }
    
    
}

fileprivate extension UIColor {
   convenience init(red: Int, green: Int, blue: Int) {
       assert(red >= 0 && red <= 255, "Invalid red component")
       assert(green >= 0 && green <= 255, "Invalid green component")
       assert(blue >= 0 && blue <= 255, "Invalid blue component")

       self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
   }

   convenience init(hex: Int) {
       self.init(
           red: (hex >> 16) & 0xFF,
           green: (hex >> 8) & 0xFF,
           blue: hex & 0xFF
       )
   }
}
