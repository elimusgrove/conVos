//
//  CollectionViewController.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import UIKit
import Foundation

class CollectionViewController: UIViewController {

    let dataProvider = DataProvider.shared
    let audioManager = AudioManager.shared
    let notificationKeyword = NSNotification.Name("new keyword added to values")
    let notificationArticle = NSNotification.Name("new article added to values")
    
    var collectionView: UICollectionView!
    var CVLayout = LiquidCollectionViewLayout()
    var startButton = SideButton()
    
    var label = UILabel()
    var blur = UIVisualEffectView()
    
    var selected = false
    
    
    var data: [Int] = Array(0..<50)
    var words: [KeyWordResult] = []
    
    override func loadView() {
        super.loadView()
        
        CVLayout.delegate = self
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: CVLayout)
        collectionView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(collectionView)
        collectionView.contentInset = UIEdgeInsets(top: 110.0, left: 0.0, bottom: 0.0, right: 0.0)
        NSLayoutConstraint.activate([
            self.view.topAnchor.constraint(equalTo: collectionView.topAnchor),
            self.view.bottomAnchor.constraint(equalTo: collectionView.bottomAnchor),
            self.view.leadingAnchor.constraint(equalTo: collectionView.leadingAnchor),
            self.view.trailingAnchor.constraint(equalTo: collectionView.trailingAnchor),
        ])
        self.collectionView = collectionView
    
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(onDidReceiveKeywords),
            name: notificationKeyword,
            object: nil
        )
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.collectionView.register(KeywordCell.self, forCellWithReuseIdentifier: KeywordCell.identifier)
        self.collectionView.alwaysBounceVertical = true
        self.collectionView.backgroundColor = .white

        let blurEffect: UIBlurEffect
        if #available(iOS 13.0, *) {
            blurEffect = UIBlurEffect(style: .light)
        } else {
            blurEffect = UIBlurEffect(style: .light)
        }
        blur.effect = blurEffect
        blur.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(blur)
        NSLayoutConstraint.activate([
            self.blur.topAnchor.constraint(equalTo: self.view.topAnchor),
            self.blur.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            self.blur.heightAnchor.constraint(equalToConstant: 150),
            self.blur.widthAnchor.constraint(equalTo: self.view.widthAnchor)
        ])

        
        setupButton()
        
        //label.font = UIFont(name: "Helvetica-Bold", size: 70)
        label.font = UIFont(name: "Menlo-Bold", size: 70)
        //label.font = UIFont(name: "Verdana", size: 70)
        label.textColor = .gray
        label.text = "conVos"
        label.translatesAutoresizingMaskIntoConstraints = false

        label.layer.shadowColor = UIColor.gray.cgColor
        label.layer.shadowOpacity = 0.2
        label.layer.shadowRadius = 2
        label.layer.shadowOffset = CGSize(width: 0.3, height: 3.0)
        label.layer.masksToBounds = false
        
        self.view.addSubview(label)
        NSLayoutConstraint.activate([
            self.label.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 59),
            self.label.rightAnchor.constraint(equalTo: self.view.rightAnchor),
            self.label.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.075),
            self.label.widthAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.325)
        ])
        

    }
    
    private func setupButton() {
        startButton.color = UIColor.gray.cgColor
        startButton.addTarget(self, action: #selector(changeButtonColor), for: .touchUpInside)
        startButton.translatesAutoresizingMaskIntoConstraints = false

        self.view.addSubview(startButton)
        NSLayoutConstraint.activate([
            self.startButton.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 50),
            self.startButton.leftAnchor.constraint(equalTo: self.view.leftAnchor),
            self.startButton.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.075),
            self.startButton.widthAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 0.1)
        ])
    }

    @objc fileprivate func changeButtonColor() {
        print("skdjfhs")
        selected.toggle()
        switch selected {
        case true:
            audioManager.isOn = true
            startButton.color = Colors.blue.cgColor
            label.textColor = Colors.blue
        case false:
            audioManager.isOn = false
            startButton.color = UIColor.gray.cgColor
            label.textColor = .gray
        }
        startButton.updateColor()
    }

    @objc func onDidReceiveKeywords() {
        let curCount = words.count
        let newCount = dataProvider.values.count
        if (newCount - curCount)%2 == 1 {
            return
        }
        words = dataProvider.values
        
        var indexPaths = [IndexPath]()
        for i in 0..<(newCount - curCount) {
            indexPaths.append(IndexPath(row: i, section: 0))
        }
        
        self.collectionView?.performBatchUpdates({
            self.collectionView?.insertItems(at: indexPaths)
        }, completion: nil)

        
    }

    
}

extension CollectionViewController: UICollectionViewDataSource {

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.words.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: KeywordCell.identifier, for: indexPath) as! KeywordCell
        cell.textLabel.text = self.words[indexPath.item].keyword
        return cell
    }
}

extension CollectionViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let yourView = collectionView.cellForItem(at: indexPath) else { return }
        
        let result = words[indexPath.row]
        if result.articles == nil || result.articles?.count != 0 {
            let detailViewController = DetailViewController()
            detailViewController.result = result
            self.present(detailViewController, animated: true, completion: nil)
        } else {
            Animations.requireUserAtencion(on: yourView)
        }
    }
}

extension CollectionViewController: LiquidLayoutDelegate {
    func collectionView(collectionView: UICollectionView, heightForCellAtIndexPath indexPath: IndexPath, width: CGFloat) -> CGFloat {
        return self.words[indexPath.item].cellHeight
    }
}

import UIKit
class Animations {
    static func requireUserAtencion(on onView: UIView) {
        let animation = CABasicAnimation(keyPath: "position")
        animation.duration = 0.04
        animation.repeatCount = 2
        animation.autoreverses = true
        animation.fromValue = NSValue(cgPoint: CGPoint(x: onView.center.x - 10, y: onView.center.y))
        animation.toValue = NSValue(cgPoint: CGPoint(x: onView.center.x + 10, y: onView.center.y))
        onView.layer.add(animation, forKey: "position")
    }
}


//["attachment",
//"radiation",
//"criminal",
//"safety",
//"demonstrate",
//"quotation",
//"location",
//"assembly",
//"conception",
//"imposter",
//"proportion",
//"miscarriage",
//"exercise",
//"discover",
//"committee",
//"ivory",
//"injection",
//"insistence",
//"serious",
//"musical",
//"willpower",
//"guerrilla",
//"minister",
//"apathy",
//"paragraph",
//"accountant",
//"flexible",
//"evening",
//"prosecute",
//"marketing",
//"designer",
//"solution",
//"superior",
//"arena",
//"productive",
//"cinema",
//"vigorous",
//"conviction",
//"sentiment",
//"primary",
//"pottery",
//"disaster",
//"houseplant",
//"frequency",
//"financial",
//"practical",
//"camera",
//"chauvinist",
//"formulate",
//"microphone"]
