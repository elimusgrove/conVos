//
//  SideButton.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit

class SideButton: UIButton {
    
    private var shadowLayer: CAShapeLayer!
    private var cornerRadius: CGFloat = 10.0
    
    private var topLeftRadius: CGFloat {
        return right ? cornerRadius : 0.0
    }
    private var topRightRadius: CGFloat {
        return right ? 0.0 : cornerRadius
    }
    private var bottomLeftRadius: CGFloat {
        return right ? cornerRadius : 0.0
    }
    private var bottomRightRadius: CGFloat {
        return right ? 0.0 : cornerRadius
    }

    
    public var color = UIColor.green.cgColor
    
    public var right = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        if shadowLayer == nil {
            shadowLayer = CAShapeLayer()
          
            shadowLayer.path = getPathFor(rect: bounds).cgPath
            shadowLayer.fillColor = color

            shadowLayer.shadowColor = UIColor.black.cgColor
            shadowLayer.shadowPath = shadowLayer.path
            shadowLayer.shadowOffset = CGSize(width: 0.3, height: 3.0)
            shadowLayer.shadowOpacity = 0.2
            shadowLayer.shadowRadius = 2
            
            
            layer.insertSublayer(shadowLayer, at: 0)
        }
    }
    
    public func updateColor() {
        if let _ = shadowLayer {
            shadowLayer.fillColor = color
        }

    }

    
    private func getPathFor(rect: CGRect) -> UIBezierPath{
        let minx = rect.minX
        let miny = rect.minY
        let maxx = rect.maxX
        let maxy = rect.maxY

        let path = UIBezierPath()
        path.move(to: CGPoint(x: minx + topLeftRadius, y: miny))
        path.addLine(to: CGPoint(x: maxx - topRightRadius, y: miny))
        path.addArc(withCenter: CGPoint(x: maxx - topRightRadius, y: miny + topRightRadius), radius: topRightRadius, startAngle:CGFloat(3 * (Double.pi / 2)), endAngle: 0, clockwise: true)
        path.addLine(to: CGPoint(x: maxx, y: maxy - bottomRightRadius))
        path.addArc(withCenter: CGPoint(x: maxx - bottomRightRadius, y: maxy - bottomRightRadius), radius: bottomRightRadius, startAngle: 0, endAngle: CGFloat((Double.pi / 2)), clockwise: true)
        path.addLine(to: CGPoint(x: minx + bottomLeftRadius, y: maxy))
        path.addArc(withCenter: CGPoint(x: minx + bottomLeftRadius, y: maxy - bottomLeftRadius), radius: bottomLeftRadius, startAngle: CGFloat((Double.pi / 2)), endAngle: CGFloat(Double.pi), clockwise: true)
        path.addLine(to: CGPoint(x: minx, y: miny + topLeftRadius))
        path.addArc(withCenter: CGPoint(x: minx + topLeftRadius, y: miny + topLeftRadius), radius: topLeftRadius, startAngle: CGFloat(Double.pi), endAngle: CGFloat(3 * (Double.pi / 2)), clockwise: true)
        path.close()
        
        return path

    }
    
    
}

