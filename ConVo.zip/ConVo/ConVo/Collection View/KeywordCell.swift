//
//  KeywordCell.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit

class KeywordCell: UICollectionViewCell {
    
    static var identifier: String = "KeywordCell"
    private var shadowLayer: CAShapeLayer!
    private var cornerRadius: CGFloat = 10.0

    public var color: CGColor = Colors.random().cgColor
    weak var textLabel: UILabel!

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let textLabel = UILabel(frame: .zero)
        textLabel.backgroundColor = .clear
        textLabel.textColor = .white
        textLabel.font = UIFont(name: "Avenir-Black", size: 30)
        textLabel.adjustsFontSizeToFitWidth = true
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        self.contentView.addSubview(textLabel)
        NSLayoutConstraint.activate([
            self.contentView.centerYAnchor.constraint(equalTo: textLabel.centerYAnchor),
            self.contentView.centerXAnchor.constraint(equalTo: textLabel.centerXAnchor),
            textLabel.widthAnchor.constraint(equalToConstant: frame.width - cornerRadius*3),
            textLabel.heightAnchor.constraint(equalToConstant: frame.height - cornerRadius)
        ])
        self.textLabel = textLabel
        self.reset()
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        if shadowLayer == nil {
            shadowLayer = CAShapeLayer()
          
            shadowLayer.path = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius).cgPath
            shadowLayer.fillColor = color

            shadowLayer.shadowColor = UIColor.black.cgColor
            shadowLayer.shadowPath = shadowLayer.path
            shadowLayer.shadowOffset = CGSize(width: 0.3, height: 3.0)
            shadowLayer.shadowOpacity = 0.2
            shadowLayer.shadowRadius = 2

            layer.insertSublayer(shadowLayer, at: 0)
        }
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.reset()
    }
    
    func reset() {
        if let _ = shadowLayer {
            if let _ = shadowLayer.superlayer {
                shadowLayer.removeFromSuperlayer()
            }
        }
        shadowLayer = nil
        self.textLabel.textAlignment = .center
    }
}

