//
//  DetailViewController.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController: UIViewController {
    
    var result: KeyWordResult!
    var blur = UIVisualEffectView()
    let notificationArticle = NSNotification.Name("new article added to values")

    var tableView = UITableView()
    
    override func viewDidLoad() {
        
        self.view.backgroundColor = .clear
        
        if result.articles == nil {
            NotificationCenter.default.addObserver(self, selector: #selector(newHeadlineLoaded), name: notificationArticle, object: nil)
        }
        
        setupViews()
    }
    
    @objc func newHeadlineLoaded() {
        if result.articles != nil {
            tableView.reloadData()
        }
    }
    
}

extension DetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (result.articles?.count) ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = HeadlineCell()
        cell.backgroundColor = .clear
        cell.textLabel?.text = result.articles![indexPath.row]
        
        return cell
    }
    
    
}

extension DetailViewController {
    fileprivate func setupViews() {
        
        let blurEffect: UIBlurEffect
        if #available(iOS 13.0, *) {
            blurEffect = UIBlurEffect(style: .systemUltraThinMaterial)
        } else {
            blurEffect = UIBlurEffect(style: .light)
        }
        blur.effect = blurEffect
        blur.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(blur)
        NSLayoutConstraint.activate([
            self.blur.topAnchor.constraint(     equalTo: self.view.topAnchor     ),
            self.blur.bottomAnchor.constraint(  equalTo: self.view.bottomAnchor  ),
            self.blur.leadingAnchor.constraint( equalTo: self.view.leadingAnchor ),
            self.blur.trailingAnchor.constraint(equalTo: self.view.trailingAnchor)
        ])

        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.separatorStyle = .none
        tableView.allowsSelection = false
        tableView.contentInset = UIEdgeInsets(top: 100.0, left: 0.0, bottom: 0.0, right: 0.0)
        tableView.tableFooterView = UIView()
        tableView.register(HeadlineCell.self, forCellReuseIdentifier: HeadlineCell.identifier)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        self.view.addSubview(tableView)
        NSLayoutConstraint.activate([
            self.view.topAnchor.constraint(equalTo: tableView.topAnchor),
            self.view.bottomAnchor.constraint(equalTo: tableView.bottomAnchor),
            self.view.leadingAnchor.constraint(equalTo: tableView.leadingAnchor),
            self.view.trailingAnchor.constraint(equalTo: tableView.trailingAnchor),
        ])
        
        

    }
}
