//
//  HeadlineCell.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit

class HeadlineCell: UITableViewCell {
    
    static var identifier: String = "KeywordCell"
    private var shadowLayer: CAShapeLayer!
    private var cornerRadius: CGFloat = 10.0

    public var color: CGColor = Colors.random().cgColor

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        textLabel?.backgroundColor = .clear
        textLabel?.textColor = .white
        textLabel?.font = UIFont(name: "Avenir-Black", size: 20)
        textLabel?.numberOfLines = 0
        textLabel?.adjustsFontSizeToFitWidth = false
        self.reset()

    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        if shadowLayer == nil {
            shadowLayer = CAShapeLayer()
            
            let rect = CGRect(x: bounds.origin.x + 10, y: bounds.origin.y + 10, width: bounds.size.width - 20, height: bounds.size.height - 20)
          
            shadowLayer.path = UIBezierPath(roundedRect: rect, cornerRadius: cornerRadius).cgPath
            shadowLayer.fillColor = color

            shadowLayer.shadowColor = UIColor.black.cgColor
            shadowLayer.shadowPath = shadowLayer.path
            shadowLayer.shadowOffset = CGSize(width: 0.3, height: 3.0)
            shadowLayer.shadowOpacity = 0.2
            shadowLayer.shadowRadius = 2

            layer.insertSublayer(shadowLayer, at: 0)
        }
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.reset()
    }
    
    func reset() {
        if let _ = shadowLayer {
            if let _ = shadowLayer.superlayer {
                shadowLayer.removeFromSuperlayer()
            }
        }
        shadowLayer = nil
        self.textLabel?.textAlignment = .center
    }
}

