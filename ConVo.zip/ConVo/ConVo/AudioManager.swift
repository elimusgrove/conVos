//
//  AudioManager.swift
//  ConVo
//
//  Created by Conley McKown on 11/2/19.
//  Copyright © 2019 Conley McKown. All rights reserved.
//

import Foundation
import UIKit
import Speech

class AudioManager: NSObject, AVAudioRecorderDelegate {
    
    static let shared = AudioManager()
    
    let dataProvider = DataProvider.shared
    
    fileprivate var recordingSession: AVAudioSession!
    fileprivate var audioRecorder: AVAudioRecorder!
    fileprivate var count = 0
    
    fileprivate var infoLabel: UILabel!
    public var isOn = false {
        didSet {
            if isOn {
                startRecording()
                looper()
            }
        }
    }
    fileprivate var switchValue = false

    private override init() {
        super.init()
        recordingSession = AVAudioSession.sharedInstance()

        do {
            try recordingSession.setCategory(.playAndRecord, mode: .default)
            try recordingSession.setActive(true)
            recordingSession.requestRecordPermission() { [unowned self] allowed in
                DispatchQueue.main.async {
                    if allowed {

                    } else {
                        // failed to record!
                    }
                }
            }
        } catch {
            // failed to record!
        }
    }
    
    public func looper() {
        if isOn {
            switchValue.toggle()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                self.count += 1
                self.finishRecording(success: true)
                self.startRecording()
                self.looper()
            }
        } else {
            self.finishRecording(success: true)
        }
    }
    
    public func setLabel(label: UILabel) {
        infoLabel = label
    }
    
    fileprivate func recognizeSpeech(url: URL) {
        let request = SFSpeechURLRecognitionRequest(url: url)
        SFSpeechRecognizer()?.recognitionTask(with: request) { (result, _) in
            if result != nil {
                if let transcription = result?.bestTranscription.formattedString {
                    if result!.isFinal {
                        self.infoLabel?.text?.append("\n" + transcription)
                        self.dataProvider.getKeywords(sentence: transcription)
                    }
                }
            }
        }
        
    }
    
    public func startRecording() {
        let audioFilename = getDocumentsDirectory().appendingPathComponent("recording\(count).m4a")

        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder.delegate = self
            audioRecorder.record()
        } catch {
            finishRecording(success: false)
        }
    }

    public func finishRecording(success: Bool) {
        
        if audioRecorder == nil {
            return
        }
        
        audioRecorder.stop()
        audioRecorder = nil

        if success {
            recognizeSpeech(url: getDocumentsDirectory().appendingPathComponent("recording\(count-1).m4a"))
        } else {
            // recording failed :(
        }
    }
    
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }

    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            finishRecording(success: false)
        }
    }

    
}















//fileprivate let audioEngine = AVAudioEngine()
//fileprivate let speechRecognizer: SFSpeechRecognizer? = SFSpeechRecognizer()
//fileprivate let request = SFSpeechAudioBufferRecognitionRequest()
//fileprivate var recognitionTask: SFSpeechRecognitionTask?
//fileprivate var strings = [String]()




//fileprivate func recordAndRecognizeSpeech() {
//    let node = audioEngine.inputNode
//    let recordingFormat = node.outputFormat(forBus: 0)
//    node.installTap(onBus: 0, bufferSize: 8192, format: recordingFormat) { buffer, _ in
//        self.request.append(buffer)
//    }
//
//    audioEngine.prepare()
//    do {
//        try audioEngine.start()
//    } catch {
//        return print(error)
//    }
//
//    guard let myRecognizer = SFSpeechRecognizer() else {
//        // A recognizer is not supported for the current local.
//        return
//    }
//    if !myRecognizer.isAvailable {
//        // A recognizer is not available rn.
//        return
//    }
//
//    recognitionTask = speechRecognizer?.recognitionTask(with: request, resultHandler: { (result, error) in
//        if let result = result {
//            let bestString = result.bestTranscription.formattedString
//            self.infoLabel.text = bestString
//
//
//            var lastString = ""
//            for segment in result.bestTranscription.segments {
//                let indexTo = bestString.index(bestString.startIndex, offsetBy: segment.substringRange.location)
//                lastString = bestString.substring(from: indexTo)
//            }
//            print("lastString: " + lastString)
//
//        } else if let error = error {
//            print(error)
//        }
//    })
//}
